<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_model extends CI_model {

	public function __construct(){
		$this->load->database();
    }
    
    public function insereUser(){
        $novoUser = array(
            'cpf' => $this->input->post('cpf'),
            'nome_user' => $this->input->post('nome_user'),
            'email' => $this->input->post('email'),
            'dt_nasc' => $this->input->post('dt_nasc'),
            'telefone' => $this->input->post('telefone'),
            'senha' => md5($this->input->post('senha'))
        );

        $chars = array(".", "-", "/", "(", ")");
        $novoUser['cpf'] = str_replace($chars, "", $novoUser['cpf']);

        $this->db->insert('usuario', $novoUser);
    }


    function buscaUser(){
        $query = $this->db->query('SELECT * FROM usuario');
        return $query->result();
    }


    function getData($cpf){
        $query = $this->db->query('SELECT * FROM usuario WHERE `cpf` = '. $cpf);
        return $query->row();
    }


    function updateUser($cpf){
        $update = array(
            'cpf' => $this->input->post('cpf'),
            'nome_user' => $this->input->post('nome_user'),
            'email' => $this->input->post('email'),
            'dt_nasc' => $this->input->post('dt_nasc'),
            'telefone' => $this->input->post('telefone'),
            'senha' => md5($this->input->post('senha'))
        );

        $this->db->where('cpf', $cpf);
        $this->db->update('usuario', $update);
    }


    function excluirUser($cpf){
        $query = $this->db->query('DELETE FROM usuario WHERE `cpf` = '. $cpf);
    }


    function validate($email, $senha){
        $this->db->where('email',$email);
        $this->db->where('senha',$senha);
        $result = $this->db->get('usuario', 1);
        return $result;
      }
}