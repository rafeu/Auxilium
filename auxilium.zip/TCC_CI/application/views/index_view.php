<?php require("cabecalho.php"); ?>

    <!-- banner part start-->
    <section class="banner_part">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-xl-6">
                    <div class="banner_text">
                        <div class="banner_text_iner">
                            <h5>Encontre eventos beneficentes</h5>
                            <h1>Auxilie nas causas de sua preferência
                                    </h1>
                            <p>Auxilium visa o encontro de pessoas dispostas a ajudar o próximo e aqueles que estão precisando de um amparo, em amplos aspectos</p>

                            <?php if($this->session->userdata('logged_in') == TRUE): ?>
                            
                                <a href="<?= site_url('Eventos_controller');?>" class="btn_2" style="margin-top: 20%">Novos Eventos</a>

                                <a href="<?= site_url('Eventos_controller');?>" class="btn_2">⠀⠀Explorar⠀⠀</a>

                            <?php else: ?>

                                <button type="button" class="btn_1" data-toggle="modal" data-target="#exampleModalCenter" style="margin-top: 20%">
                                ⠀⠀⠀Login⠀⠀⠀
                                </button>

                                <a href="<?= site_url('User_controller/indexCadastro'); ?>" class="btn_2">Cadastre-se</a>
                            
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
                <div class="banner_index"></div>
            </div>
           
            <!-- modal -->
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalCenterTitle">Login</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                    <div class="modal-body">
                        <form name="formLogin" method="post" action="<?= site_url('User_controller/auth') ?> " >
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <label for="senha">Senha</label>
                                <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha">
                            </div>
                    </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary" value="save">Logar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- fim do modal -->
    </section>
</body>
    <!-- banner part start-->

    <?php require("rodape.php"); ?>
