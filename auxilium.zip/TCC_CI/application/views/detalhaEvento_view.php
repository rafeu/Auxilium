<?php include('cabecalho.php'); ?>

<section class="banner_part">

    <div class="container">
        <div class="row align-items-center">
            <div class="participe_eventos">

                <!-- AQUI COLOCA O NOME, DEIXA AS CLASS -->
                <div>
                    <h1 class="participe_variavelnome" style="width: 100%; text-align: center; border-bottom: 2px solid #0c2e60;"><?= $row->nome_evento ?></h1>
                </div>
            </div>

                <!-- AQUI LINKAR A IMG QUANDO ESTIVER COM A OPÇÃO -->
            <div class="img_detalha_evento" style="background: transparent url(<?= base_url(); ?>assets/imagens/evento.jpg); width: 1170px; "></div>

            <div style="descricao_text">
            <!-- AQUI COLOCA A DESCRICAO -->
                <div class="descricao_detalha jumbotron border_radius_none">
                    <h3 ><?= $row->descricao ?></h3>

                    <div>
                    <br><br>
                    <h4>Data </h4><br><h4 style="color: grey;"> Inicio: <?= $row->dataInicio?> - <?=$row->horaInicio ?> </h4><h4 style="color: grey; border-bottom: solid 2px; height: 50px;"> Fim: <?= $row->dataFim?> - <?= $row->horaFim ?> </h4>
                    <br>
                    <?php $doacao = explode(",", $row->tipo_doacao_requerida); ?>
                    <h4>Doações Necessárias </h4><br><h4 style="color: grey;"> <?= $doacao[0]; ?></h4><h4 style="color: grey;"> <?= $doacao[1] ?></h4>
                    </div>

                <!-- AQUI CADASTRA A DOAÇÃO -->
                    <div class="descricao_envia">
                        <a href="#" class="btn_1" style="color: white; float: right;"> Realizar Doação </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

</section>


<?php include('rodape.php'); ?>