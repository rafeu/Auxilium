-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 04-Jul-2019 às 01:59
-- Versão do servidor: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `acc_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `alimento`
--

CREATE TABLE `alimento` (
  `qtd_doacao` int(5) DEFAULT NULL,
  `descricao_doacao` varchar(255) DEFAULT NULL,
  `id_alimento` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `avalia`
--

CREATE TABLE `avalia` (
  `id_evento` int(10) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairros`
--

CREATE TABLE `bairros` (
  `nome_bairro` varchar(150) DEFAULT NULL,
  `cd_bairro` int(15) NOT NULL,
  `cd_cidade` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `brinquedo`
--

CREATE TABLE `brinquedo` (
  `qtd_doacao` int(5) DEFAULT NULL,
  `id_brinquedo` int(15) NOT NULL,
  `descricao_doacao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidade`
--

CREATE TABLE `cidade` (
  `nome_cidade` varchar(150) DEFAULT NULL,
  `cd_cidade` int(15) NOT NULL,
  `cd_uf` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comentario`
--

CREATE TABLE `comentario` (
  `dt_comentario` date DEFAULT NULL,
  `horario_comentario` time DEFAULT NULL,
  `texto` varchar(255) DEFAULT NULL,
  `id_comentario` int(10) NOT NULL,
  `id_evento` int(10) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cria`
--

CREATE TABLE `cria` (
  `id_evento` int(10) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `diversos`
--

CREATE TABLE `diversos` (
  `descricao_doacao` varchar(255) DEFAULT NULL,
  `id_diversos` int(15) NOT NULL,
  `qtd_doacao` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `doacao`
--

CREATE TABLE `doacao` (
  `id_doacao` int(15) NOT NULL,
  `tipo_doacao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE `eventos` (
  `descricao` varchar(2555) DEFAULT NULL,
  `dataInicio` varchar(10) DEFAULT NULL,
  `dataFim` varchar(10) DEFAULT NULL,
  `num_avaliacoes` int(5) DEFAULT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `id_evento` int(10) NOT NULL,
  `horaInicio` time DEFAULT NULL,
  `horaFim` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `eventos`
--

INSERT INTO `eventos` (`descricao`, `dataInicio`, `dataFim`, `num_avaliacoes`, `nome`, `id_evento`, `horaInicio`, `horaFim`) VALUES
('Ay  Fonsi  DY  Oh Oh no, oh no Oh yeah Diridiri, dirididi Daddy  Go ', 'ratito ', 'mirándote ', NULL, 'Despacito 2', 125, '00:00:00', '00:00:00'),
('Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'lorem', 'lorem', NULL, 'Lorem', 126, '00:00:00', '00:00:00');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornece`
--

CREATE TABLE `fornece` (
  `cpf` varchar(15) DEFAULT NULL,
  `id_alimento` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logradouro`
--

CREATE TABLE `logradouro` (
  `nome_log` varchar(255) DEFAULT NULL,
  `cd_logradouro` int(15) NOT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `cd_bairro` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorre`
--

CREATE TABLE `ocorre` (
  `cd_logradouro` int(15) DEFAULT NULL,
  `id_evento` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `participa`
--

CREATE TABLE `participa` (
  `id_evento` int(10) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `recebe`
--

CREATE TABLE `recebe` (
  `id_evento` int(10) DEFAULT NULL,
  `id_doacao` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tecidos`
--

CREATE TABLE `tecidos` (
  `qtd_doacao` int(5) DEFAULT NULL,
  `descricao_doacao` varchar(255) DEFAULT NULL,
  `id_tecidos` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_alimento`
--

CREATE TABLE `tipo_alimento` (
  `id_doacao` int(15) DEFAULT NULL,
  `id_alimento` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_brinquedo`
--

CREATE TABLE `tipo_brinquedo` (
  `id_doacao` int(15) DEFAULT NULL,
  `id_brinquedo` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_diversos`
--

CREATE TABLE `tipo_diversos` (
  `id_doacao` int(15) DEFAULT NULL,
  `id_diversos` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_tecido`
--

CREATE TABLE `tipo_tecido` (
  `id_doacao` int(15) DEFAULT NULL,
  `id_tecidos` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `uf`
--

CREATE TABLE `uf` (
  `cd_uf` int(15) NOT NULL,
  `nome_uf` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `cpf` varchar(11) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `tip_user` tinyint(1) NOT NULL DEFAULT '0',
  `nome_user` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `dt_nasc` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `telefone` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `senha` varchar(150) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`cpf`, `email`, `tip_user`, `nome_user`, `dt_nasc`, `telefone`, `senha`) VALUES
('03757306996', 'suzanefm@gmail.com', 0, 'Suzane Figueiredo Martins', '30/01/1975', '(47) 3034-8594', 'df1ed2a75f660b8d0969585fe3510d0a'),
('10715098556', 'fabiocm@gmail.com', 0, 'Fabio Emanuel da Cunha', '28/05/1998', '(47) 3034-3289', 'a3daf5f51bb41a678f410b525f02996b'),
('12345678912', 'cabelo@gmail.com', 0, 'Cabelo', '13/11/2004', '(98) 9782-3191', '60f82bf3613ee90a662d22670ecbac50'),
('93615302915', 'paulogabi@gmail.com', 0, 'Paulo Gabriel de York', '15/12/1999', '(47) 9595-6565', 'adcebeafbb16fc1ac715d06e0d66b986');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alimento`
--
ALTER TABLE `alimento`
  ADD PRIMARY KEY (`id_alimento`);

--
-- Indexes for table `bairros`
--
ALTER TABLE `bairros`
  ADD PRIMARY KEY (`cd_bairro`);

--
-- Indexes for table `brinquedo`
--
ALTER TABLE `brinquedo`
  ADD PRIMARY KEY (`id_brinquedo`);

--
-- Indexes for table `cidade`
--
ALTER TABLE `cidade`
  ADD PRIMARY KEY (`cd_cidade`);

--
-- Indexes for table `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`id_comentario`);

--
-- Indexes for table `diversos`
--
ALTER TABLE `diversos`
  ADD PRIMARY KEY (`id_diversos`);

--
-- Indexes for table `doacao`
--
ALTER TABLE `doacao`
  ADD PRIMARY KEY (`id_doacao`);

--
-- Indexes for table `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id_evento`);

--
-- Indexes for table `logradouro`
--
ALTER TABLE `logradouro`
  ADD PRIMARY KEY (`cd_logradouro`);

--
-- Indexes for table `tecidos`
--
ALTER TABLE `tecidos`
  ADD PRIMARY KEY (`id_tecidos`);

--
-- Indexes for table `uf`
--
ALTER TABLE `uf`
  ADD PRIMARY KEY (`cd_uf`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`cpf`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alimento`
--
ALTER TABLE `alimento`
  MODIFY `id_alimento` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bairros`
--
ALTER TABLE `bairros`
  MODIFY `cd_bairro` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `brinquedo`
--
ALTER TABLE `brinquedo`
  MODIFY `id_brinquedo` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cidade`
--
ALTER TABLE `cidade`
  MODIFY `cd_cidade` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comentario`
--
ALTER TABLE `comentario`
  MODIFY `id_comentario` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `diversos`
--
ALTER TABLE `diversos`
  MODIFY `id_diversos` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doacao`
--
ALTER TABLE `doacao`
  MODIFY `id_doacao` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id_evento` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `logradouro`
--
ALTER TABLE `logradouro`
  MODIFY `cd_logradouro` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tecidos`
--
ALTER TABLE `tecidos`
  MODIFY `id_tecidos` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uf`
--
ALTER TABLE `uf`
  MODIFY `cd_uf` int(15) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
