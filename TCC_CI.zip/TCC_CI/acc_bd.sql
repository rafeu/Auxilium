-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26-Ago-2019 às 16:44
-- Versão do servidor: 10.4.6-MariaDB
-- versão do PHP: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `acc_bd`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bairros`
--

CREATE TABLE `bairros` (
  `nome_bairro` varchar(150) DEFAULT NULL,
  `cd_bairro` int(15) NOT NULL,
  `cd_cidade` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidade`
--

CREATE TABLE `cidade` (
  `nome_cidade` varchar(150) DEFAULT NULL,
  `cd_cidade` int(15) NOT NULL,
  `cd_uf` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `comentario`
--

CREATE TABLE `comentario` (
  `dt_comentario` date DEFAULT NULL,
  `horario_comentario` time DEFAULT NULL,
  `texto` varchar(255) DEFAULT NULL,
  `id_comentario` int(10) NOT NULL,
  `id_evento` int(10) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `cria`
--

CREATE TABLE `cria` (
  `id_evento` int(10) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `doacao`
--

CREATE TABLE `doacao` (
  `id_doacao` int(15) NOT NULL,
  `tipo_doacao` varchar(255) DEFAULT NULL,
  `qtd_doacao` int(11) NOT NULL,
  `id_evento_fk` int(11) NOT NULL,
  `cpf_fk` varchar(11) CHARACTER SET utf8 NOT NULL,
  `descricao_doacao` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `doacao`
--

INSERT INTO `doacao` (`id_doacao`, `tipo_doacao`, `qtd_doacao`, `id_evento_fk`, `cpf_fk`, `descricao_doacao`) VALUES
(5, 'Brinquedo', 5, 128, '12312345645', 'Carrinhos Hot Wheels usados.'),
(6, 'Brinquedo', 2, 128, '12312345645', 'Bonecas Baby Alive novas.');

-- --------------------------------------------------------

--
-- Estrutura da tabela `eventos`
--

CREATE TABLE `eventos` (
  `descricao` varchar(2555) DEFAULT NULL,
  `dataInicio` varchar(10) DEFAULT NULL,
  `dataFim` varchar(10) DEFAULT NULL,
  `num_avaliacoes` int(5) DEFAULT NULL,
  `nome_evento` varchar(100) DEFAULT NULL,
  `id_evento` int(10) NOT NULL,
  `horaInicio` time DEFAULT NULL,
  `horaFim` time DEFAULT NULL,
  `tipo_doacao_requerida` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `eventos`
--

INSERT INTO `eventos` (`descricao`, `dataInicio`, `dataFim`, `num_avaliacoes`, `nome_evento`, `id_evento`, `horaInicio`, `horaFim`, `tipo_doacao_requerida`) VALUES
('Ay  Fonsi  DY  Oh Oh no, oh no Oh yeah Diridiri, dirididi Daddy  Go ', 'ratito ', 'mirándote ', NULL, 'Despacito 2', 125, '00:00:00', '00:00:00', 'Brinquedos, Alimento'),
('Lorem ipsum dolor sit amet', 'lorem ', 'lorem ', NULL, 'Lorem ', 126, '00:00:00', '00:00:00', 'Alimento, Agasalho'),
('GALERAAaaaa o luciano hulk ta vindooooo', '12/12/2012', '12/12/2012', NULL, 'Luciano Hulk no IFC', 128, '13:00:00', '14:00:00', 'Brinquedos, Agasalhos');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornece`
--

CREATE TABLE `fornece` (
  `cpf` varchar(15) DEFAULT NULL,
  `id_alimento` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `logradouro`
--

CREATE TABLE `logradouro` (
  `nome_log` varchar(255) DEFAULT NULL,
  `cd_logradouro` int(15) NOT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `cd_bairro` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `ocorre`
--

CREATE TABLE `ocorre` (
  `cd_logradouro` int(15) DEFAULT NULL,
  `id_evento` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `participa`
--

CREATE TABLE `participa` (
  `id_evento` int(10) DEFAULT NULL,
  `cpf` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `recebe`
--

CREATE TABLE `recebe` (
  `id_evento` int(10) DEFAULT NULL,
  `id_doacao` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `uf`
--

CREATE TABLE `uf` (
  `cd_uf` int(15) NOT NULL,
  `nome_uf` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `cpf` varchar(11) CHARACTER SET utf8 NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `tip_user` tinyint(1) NOT NULL DEFAULT 0,
  `nome_user` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `dt_nasc` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `telefone` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `senha` varchar(150) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`cpf`, `email`, `tip_user`, `nome_user`, `dt_nasc`, `telefone`, `senha`) VALUES
('03757306996', 'suzanefm@gmail.com', 0, 'Suzane Figueiredo Martins', '30/01/1975', '(47) 3034-8594', 'df1ed2a75f660b8d0969585fe3510d0a'),
('10715098556', 'fabiocm@gmail.com', 0, 'Fabio Emanuel da Cunha', '28/05/1998', '(47) 3034-3289', 'a3daf5f51bb41a678f410b525f02996b'),
('12312345645', 'admin@admin.com', 1, 'admin', '15/12/2000', '(15) 1515-1515', '21232f297a57a5a743894a0e4a801fc3'),
('12345678912', 'cabelo@gmail.com', 0, 'Cabelo', '13/11/2004', '(98) 9782-3191', '60f82bf3613ee90a662d22670ecbac50'),
('93615302915', 'paulogabi@gmail.com', 0, 'Paulo Gabriel de York', '15/12/1999', '(47) 9595-6565', 'adcebeafbb16fc1ac715d06e0d66b986');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bairros`
--
ALTER TABLE `bairros`
  ADD PRIMARY KEY (`cd_bairro`);

--
-- Índices para tabela `cidade`
--
ALTER TABLE `cidade`
  ADD PRIMARY KEY (`cd_cidade`);

--
-- Índices para tabela `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`id_comentario`);

--
-- Índices para tabela `doacao`
--
ALTER TABLE `doacao`
  ADD PRIMARY KEY (`id_doacao`),
  ADD KEY `Evento_doacao_fk` (`id_evento_fk`),
  ADD KEY `caduser_doacao` (`cpf_fk`);

--
-- Índices para tabela `eventos`
--
ALTER TABLE `eventos`
  ADD PRIMARY KEY (`id_evento`);

--
-- Índices para tabela `logradouro`
--
ALTER TABLE `logradouro`
  ADD PRIMARY KEY (`cd_logradouro`);

--
-- Índices para tabela `uf`
--
ALTER TABLE `uf`
  ADD PRIMARY KEY (`cd_uf`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`cpf`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bairros`
--
ALTER TABLE `bairros`
  MODIFY `cd_bairro` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `cidade`
--
ALTER TABLE `cidade`
  MODIFY `cd_cidade` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `comentario`
--
ALTER TABLE `comentario`
  MODIFY `id_comentario` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `doacao`
--
ALTER TABLE `doacao`
  MODIFY `id_doacao` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `eventos`
--
ALTER TABLE `eventos`
  MODIFY `id_evento` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT de tabela `logradouro`
--
ALTER TABLE `logradouro`
  MODIFY `cd_logradouro` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `uf`
--
ALTER TABLE `uf`
  MODIFY `cd_uf` int(15) NOT NULL AUTO_INCREMENT;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `doacao`
--
ALTER TABLE `doacao`
  ADD CONSTRAINT `Evento_doacao_fk` FOREIGN KEY (`id_evento_fk`) REFERENCES `eventos` (`id_evento`),
  ADD CONSTRAINT `caduser_doacao` FOREIGN KEY (`cpf_fk`) REFERENCES `usuario` (`cpf`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
