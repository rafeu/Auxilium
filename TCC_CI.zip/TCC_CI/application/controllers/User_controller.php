<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_controller extends CI_Controller {

	public function __construct(){
		parent::__construct();

		$this->load->model('User_model');

	}

	public function index(){
		$data['result'] = $this->User_model->buscaUser();
		$this->load->view('user_view', $data);
	}

	public function indexCadastro(){
		$data['result'] = $this->User_model->buscaUser();
		$this->load->view('cadastroUser_view', $data);
	}

	public function indexEditar($cpf){
		$data['row'] = $this->User_model->getData($cpf);
		$this->load->view('editUser_view', $data);
	}

	public function createUser(){	
		$this->User_model->insereUser();
		redirect("User_controller");	
	}

	public function editUser(){
		$this->User_model->editUser();
		redirect("User_controller");	
	}

	public function updateUser($cpf){
		$this->User_model->updateUser($cpf);
		redirect("User_controller");
	}

	public function excluirUser($cpf){
		$this->User_model->excluirUser($cpf);
		redirect("User_controller");	
	}

	function auth(){
		$email    = $this->input->post('email',TRUE);
		$senha 	  = md5($this->input->post('senha',TRUE));
		$validate = $this->User_model->validate($email, $senha);
		if($validate->num_rows() > 0){
			$data  = $validate->row_array();
			$nome  = $data['nome_user'];
			$email = $data['email'];
			$tip_user = $data['tip_user'];
			$sesdata = array(
				'nome_user' => $nome,
				'email'     => $email,
				'tip_user'  => $tip_user,
				'logged_in' => TRUE
			);
			
			$this->session->set_userdata($sesdata);

			// access login for admin
			if($tip_user === '0'){
				redirect('page');
	 
			// access login for staff
			}elseif($tip_user === '1'){
				redirect('page/staff');
	 
			// access login for author
			}else{
				redirect('page/author');
			}
		}else{
			echo $this->session->set_flashdata('msg','Email ou senha incorretos.');
			redirect('Dashboard');
		}
	}
	 
	function logout(){
	  	$this->session->sess_destroy();
	  	redirect('principal');
	 }

	function perfil(){
		//$data['result'] = $this->User_model->buscaUser();
		$this->load->view('perfil_view'  /* , $data*/);
	}



}
