<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eventos_controller extends CI_Controller {

	public function __construct(){
		parent::__construct();

		$this->load->model('Eventos_model');

	}

	public function index(){
		$data['result'] = $this->Eventos_model->buscaEventos();
		$this->load->view('eventos_view', $data);
	}

	public function indexCadastro(){
		$data['result'] = $this->Eventos_model->buscaEventos();
		$this->load->view('cadastroEvento_view', $data);
	}

	public function indexEditar($id_evento){
		$data['row'] = $this->Eventos_model->getData($id_evento);
		$this->load->view('editEvento_view', $data);
	}

	public function createEvento(){	
		$this->Eventos_model->insereEvento();
		redirect("Eventos_controller");	
	}

	public function editEvento(){
		$this->Eventos_model->editEvento();
		redirect("Eventos_controller");	
	}

	public function updateEvento($id_evento){
		$this->Eventos_model->updateEvento($id_evento);
		redirect("Eventos_controller");
	}

	public function excluirEvento($id_evento){
		$this->Eventos_model->excluirEvento($id_evento);
		redirect("Eventos_controller");	
	}

	function perfilEvento(){
		//$data['result'] = $this->Eventos_model->buscaEventos();
		$this->load->view('detalhaEvento_view'  /* , $data*/);
	}



}
