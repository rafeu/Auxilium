<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eventos_model extends CI_model {

	public function __construct(){
		$this->load->database();
    }
    
    public function insereEvento(){
        $novoEvento = array(
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'dataInicio' => $this->input->post('dataInicio'),
            'dataFim' => $this->input->post('dataFim'),
            'horaInicio' => $this->input->post('horaInicio'),
            'horaFim' => $this->input->post('horaFim')
        );
        
        $this->db->insert('eventos', $novoEvento);
    }


    function buscaEventos(){
        $query = $this->db->query('SELECT * FROM eventos');
        return $query->result();
    }


    function getData($id_evento){
        $query = $this->db->query('SELECT * FROM eventos WHERE `id_evento` = '. $id_evento);
        return $query->row();
    }


    function updateEvento($id_evento){
        $update = array(
            'nome' => $this->input->post('nome'),
            'descricao' => $this->input->post('descricao'),
            'dataInicio' => $this->input->post('dataInicio'),
            'dataFim' => $this->input->post('dataFim'),
            'horaInicio' => $this->input->post('horaInicio'),
            'horaFim' => $this->input->post('horaFim')
        );

        $this->db->where('id_evento', $id_evento);
        $this->db->update('eventos', $update);
    }


    function excluirEvento($id_evento){
        $query = $this->db->query('DELETE FROM eventos WHERE `id_evento` = '. $id_evento);
    }

}