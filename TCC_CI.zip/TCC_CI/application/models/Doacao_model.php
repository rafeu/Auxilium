<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Doacao_model extends CI_model {

	public function __construct(){
		$this->load->database();
    }
    
    public function insereDoacao(){
        $novaDoacao = array(
            'tipo_doacao' => $this->input->post('tipo_doacao'),
            'descricao_doacao' => $this->input->post('descricao_doacao'),
            'qtd_doacao' => $this->input->post('qtd_doacao'),
            'cpf_fk' => $this->input->post('cpf'),
            'id_evento_fk' => $this->input->post('id_evento')
        );
        
        $this->db->insert('doacao', $novaDoacao);
    }


    function buscaDoacao(){
        $query = $this->db->query('SELECT * FROM doacao');
        return $query->result();
    }


    function getDataDoacao($cpf){
        $query = $this->db->query('SELECT id_doacao, tipo_doacao, qtd_doacao, nome_evento, descricao_doacao FROM doacao, usuario, eventos WHERE `cpf` = `cpf_fk` and `id_evento` = `id_evento_fk` and `cpf_fk` = ' . $cpf);
        return $query->row();
    }


    function updateDoacao($id_doacao){
        $update = array(
            'tipo_doacao' => $this->input->post('tipo_doacao'),
            'descricao_doacao' => $this->input->post('descricao_doacao'),
            'qtd_doacao' => $this->input->post('qtd_doacao'),
            'cpf_fk' => $this->input->post('cpf'),
            'id_evento_fk' => $this->input->post('id_evento')
        );

        $this->db->where('id_doacao', $id_doacao);
        $this->db->update('doacao', $update);
    }


    function excluirDoacao($id_doacao){
        $query = $this->db->query('DELETE FROM doacao WHERE `id_doacao` = '. $id_doacao);
    }

}