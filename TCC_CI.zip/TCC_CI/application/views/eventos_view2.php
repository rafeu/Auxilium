<?php require("cabecalho.php"); ?>

    <!-- modal login -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Login</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                

            <div class="modal-body">
                <form name="formLogin" method="post" action="<?= site_url('User_controller/auth') ?> " >
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha">
                    </div>
            </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" value="save">Logar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- fim do modal -->

    <!-- Modal Cadastro -->
    <div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Cadastro</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form name="formNovoEvento" method="post" action="<?= site_url('Eventos_controller/createEvento') ?> " >
                    <div class="form-group">
                        <label for="Nome">Nome do Evento</label>
                        <input type="text" class="form-control" name="nome" id="Nome" placeholder="Nome do evento">
                        <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                    </div>
                    <div class="form-group">
                        <label for="descricao">Descrição</label>
                        <input type="text" class="form-control" name="descricao" id="descricao" placeholder="Descricao">
                    </div>
                    <div class="form-group">
                        <label for="dataInicio">Data de inicio</label>
                        <input type="text" class="form-control" name="dataInicio" id="data" placeholder="Data de inicio">
                    </div>
                    <div class="form-group">
                        <label for="dataFim">Data de fim</label>
                        <input type="text" class="form-control" name="dataFim" id="data" placeholder="Data de Fim">
                        <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                    </div>
                    <div class="form-group">
                        <label for="horaInicio">Horário de inicio</label>
                        <input type="text" class="form-control" name="horaInicio" id="hora" placeholder="Horário de inicio">
                        <small class="form-text text-muted">Residencial ou celular.</small>
                    </div>
                    <div class="form-group">
                        <label for="horaFim">Horário de fim</label>
                        <input type="text" class="form-control" name="horaFim" id="hora" placeholder="Horário de fim">
                    </div>

                    <!-- <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                    </div> -->

                    <button type="submit" class="btn btn-primary" value="save">Cadastrar</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
            </div>
        </div>
    </div>
    <!-- end Modal -->

    <!-- banner part start-->
    <section class="banner_part">
        <div class="container">
        <div class="row" style="margin-top: 20%; margin-left: 5%;">  
               
                <div class="divBusca">
                    <div src="<?= base_url();?>assets/imagens/pesquisarIcon.png" id="iconPesquisa" alt="Buscar"></div>
                    <input type="text" id="txtBusca" placeholder="Buscar..."/>
                </div>
            
                <div class="divider"></div>
                
                <?php if($this->session->userdata('logged_in') == TRUE): ?>      
                    <div style=" float: left;">
                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" >
                            Cadastrar
                        </button>
                    </div>
                <?php endif; ?>
                

            <div class="row align-items-center" style="height: 500px;">

                <div class="card-deck">

                    <?php foreach($result as $evento){ ?>

                        <div class="card">
                            <!-- <img class="card-img-top" src=".../100px180/" alt="Imagem de capa do card"> -->
                            <div class="card-text" style="background-image: url(<?= base_url(); ?>assets/imagens/evento.jpg); height: 75px;" class="card-img-top" alt="..."></div>
                            <div class="card-body">
                                <a href="<?= site_url('Eventos_controller/perfilEvento');?>/<?= $evento->id_evento ?>"><h5 class="card-title"><?= $evento->nome_evento; ?></h5></a>
                                <p class="card-text"><?= $evento->descricao; ?></p>
                            </div>
                            <div class="card-footer">
                                <a href="<?= site_url('Eventos_controller/perfilEvento');?>/<?= $evento->id_evento ?>" class="btn btn-primary" style="padding: 5px; display: inline;" >Acessar</a>
                                <div style="float: right;">

                                <?php if($this->session->userdata('logged_in') == TRUE): 
                                        if($this->session->userdata('tip_user') === 1): ?>
                                        

                                    <a href="<?= site_url('Eventos_controller/indexEditar');?>/<?=$evento->id_evento; ?>">Editar</a> | 
                                    <a href="<?= site_url('Eventos_controller/excluirEvento');?>/<?=$evento->id_evento; ?>">Excluir</a>

                                <?php   endif;
                                    endif; ?>

                                </div>
                            </div>
                        </div>

                    <?php } ?>

                </div>

                        

                        

                </div>               

            </div>
        </div>
    </section>
    <!-- banner part start-->

    <?php require("rodape.php"); ?>
