<?php require("cabecalho.php"); ?>

<section class="banner_part">
    <div class="container" style="margin-top: 10%;">
        <h1> Editar Usuário </h1>
        <br>
        <br>
            <form name="formNovoEvento" method="post" action="<?= site_url('User_controller/updateUser')?>/<?= $row->cpf; ?>" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="cpf">CPF</label>
                    <input type="text" class="form-control" name="cpf" id="cpf" value="<?= $row->cpf; ?>" placeholder="CPF" required>
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="nomeCompleto">Nome</label>
                    <input type="text" class="form-control" name="nome_user" id="nomeCompleto" value="<?= $row->nome_user; ?>" placeholder="Nome Completo">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" id="email" value="<?= $row->email; ?>" placeholder="Email">
                </div>
                <div class="form-group">
                    <label for="dataNascimento">Data de Nascimento</label>
                    <input type="text" class="form-control" name="dt_nasc" id="dataNascimento" value="<?= $row->dt_nasc; ?>" placeholder="Data de Nascimento">
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="text" class="form-control" name="telefone" id="telefone" value="<?= $row->telefone; ?>" placeholder="Telefone">
                    <small class="form-text text-muted">Residencial ou celular.</small>
                </div>
                <div>
                    <label for="imagem_perfil">Foto de perfil</label><br>
                    <input type="file" name="arquivo">
                    <small class="form-text text muted">Foto de perfil não obrigatória.</small>
                </div>
                <br>
                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" class="form-control" name="senha" id="senha" value="" placeholder="Senha" required>
                </div>


                <div class="form-group">
                    <label for="confirmaSenha">Confirmar Senha</label>
                    <input type="password" class="form-control" name="" id="confirmaSenha" placeholder="Confirmar senha" required>
                </div>


                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1" required>
                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                </div>
            
            

                <button type="submit" class="btn btn-primary" value="save">Atualizar</button>
            </form>
        </div>
    </div>
</section>
<br>
<br>

<?php require("rodape.php"); ?>