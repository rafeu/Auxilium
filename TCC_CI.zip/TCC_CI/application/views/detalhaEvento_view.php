<?php include('cabecalho.php'); ?>

<div style="margin-top: 50%;"></div>

<?php include('rodape.php'); ?>