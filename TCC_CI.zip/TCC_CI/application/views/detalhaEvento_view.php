<?php include('cabecalho.php'); ?>

<section class="banner_part">

    <div class="container">
        <div class="row align-items-center">
            <div class="detalha_container">

                <!-- AQUI COLOCA O NOME, DEIXA AS CLASS -->
            <div>
                    <h1 class="nome_detalha" style="width: 44%; text-align: center; border-bottom: 2px solid #0c2e60;"><?= $row->nome_evento ?></h1>
                </div>
            </div>
                

                <!-- AQUI LINKAR A IMG QUANDO ESTIVER COM A OPÇÃO -->
            <div class="img_detalha" style="background: transparent url(<?= base_url(); ?>assets/imagens/evento.jpg); width: 43%; "></div>

            
            
            <!-- AQUI COLOCA A DESCRICAO -->
                <div class="descricao_detalha">
                    <h3 ><?= $row->descricao ?></h3>

                    
                    <div>
                    <br><br>
                    <h4>Data </h4><br><h4 style="color: grey;"> Inicio: <?= $row->dataInicio?> - <?=$row->horaInicio ?> </h4><h4 style="color: grey; border-bottom: solid 2px; height: 50px;"> Fim: <?= $row->dataFim?> - <?= $row->horaFim ?> </h4>
                    <br>

                    <h4>Doações Necessárias </h4>
                    <br>

                    <?php $doacoes = explode(",", $row->tipo_doacao_requerida); 
                        foreach ($doacoes as $doacao):
                    ?>
                        
                        <h4 style="color: grey;"> <?= $doacao ?></h4>
                    
                    <?php    
                        endforeach;
                    ?>
                    
                    </div>

                    <?php if($this->session->userdata('logged_in') == TRUE): ?>
                <!-- AQUI CADASTRA A DOAÇÃO -->
                    <div class="descricao_envia">
                        <a href="<?= site_url('Doacao_controller/indexCadastrar');?>/<?=$row->id_evento; ?>" class="btn_1" style="color: white; float: right;"> Realizar Doação </a>
                    </div>
                    <?php endif; ?>

                </div>
        </div>
    </div>

    

</section>


<?php include('rodape.php'); ?>