<?php include('cabecalho.php'); ?>

<section class="banner_part">
        <div class="container">
            <div class="row align-items-center">
            
            </div>
        </div>
</section>

<?php include('rodape.php'); ?>