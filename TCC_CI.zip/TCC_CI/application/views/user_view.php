<?php require("cabecalho.php"); ?>

    <!-- banner part start-->
    <section class="banner_part">
        <div class="container">
            <div class="row align-items-center">

            <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro" style="margin-top: 20%">
                Cadastrar
                </button>

                <!-- Modal Cadastro -->
                <div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalCenterTitle">Cadastro</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form name="formNovoEvento" method="post" action="<?= site_url('User_controller/createUser') ?> " >
                                <div class="form-group">
                                    <label for="cpf">CPF</label>
                                    <input type="text" class="form-control" name="cpf" id="cpf" placeholder="CPF" required>
                                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                                </div>
                                <div class="form-group">
                                    <label for="nomeCompleto">Nome</label>
                                    <input type="text" class="form-control" name="nome_user" id="nomeCompleto" placeholder="Nome Completo">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <label for="dataNascimento">Data de Nascimento</label>
                                    <input type="text" class="form-control" name="dt_nasc" id="dataNascimento" placeholder="Data de Nascimento">
                                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                                </div>
                                <div class="form-group">
                                    <label for="telefone">Telefone</label>
                                    <input type="text" class="form-control" name="telefone" id="telefone" placeholder="Telefone">
                                    <small class="form-text text-muted">Residencial ou celular.</small>
                                </div>
                                <div class="form-group">
                                    <label for="senha">Senha</label>
                                    <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha" required>
                                </div>
                                <div class="form-group">
                                    <label for="confirmaSenha">Confirmar Senha</label>
                                    <input type="password" class="form-control" name="" id="confirmaSenha" placeholder="Confirmar senha" required>
                                </div>

                                <!-- <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                                </div> -->

                                <button type="submit" class="btn btn-primary" id="submit" value="save">Registrar</button>
                            </form>

                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
                                <script>
                                    $(function(){
                                        $("#submit").click(function(){
                                        var senha = $("#senha").val();
                                        var senha2 = $("#confirmaSenha").val();
                                            if(senha != senha2){
                                                event.preventDefault();
                                                alert("As senhas não são iguais!");
                                            }
                                        });
                                    });
                            </script>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                        </div>
                    </div>
                </div>
                <!-- end Modal -->

                <table class="table" style="margin-top: 2%;">
                    <thead>
                        <tr>
                            <th scope="col">CPF</th>
                            <th scope="col">Nome</th>
                            <th scope="col">Email</th>
                            <th scope="col">Telefone</th>
                            <th scope="col">Nascimento</th>
                            <th scope="col">Opções</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php foreach($result as $usuario){ ?>

                        <tr>
                            <th scope="row"><?= $usuario->cpf; ?></th>
                            <td><?= $usuario->nome_user; ?></td>
                            <td><?= $usuario->email; ?></td>
                            <td><?= $usuario->telefone; ?></td>
                            <td><?= $usuario->dt_nasc; ?></td>
                            <td> <a href="<?= site_url('User_controller/indexEditar');?>/<?=$usuario->cpf; ?>">Editar</a> | 
                                 <a href="<?= site_url('User_controller/excluirUser');?>/<?=$usuario->cpf; ?>">Excluir</a>

                            </td>
                        </tr>

                    <?php } ?>

                    </tbody>
                </table>

                <!-- Modal Editar 


                <div class="modal fade" id="modalEditar" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalCenterTitle">Cadastro</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form name="formNovoEvento" method="post" action="" >
                                <div class="form-group">
                                    <label for="cpf">CPF</label>
                                    <input type="text" class="form-control" name="cpf" id="cpfEdit" placeholder="CPF">
                                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                                </div>
                                <div class="form-group">
                                    <label for="nomeCompleto">Nome</label>
                                    <input type="text" class="form-control" name="nome_user" id="nomeCompletoEdit" placeholder="Nome Completo">
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" name="email" id="emailEdit" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <label for="dataNascimento">Data de Nascimento</label>
                                    <input type="text" class="form-control" name="dt_nasc" id="dataNascimentoEdit" placeholder="Data de Nascimento">
                                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                                </div>
                                <div class="form-group">
                                    <label for="telefone">Telefone</label>
                                    <input type="text" class="form-control" name="telefone" id="telefoneEdit" placeholder="Telefone">
                                    <small class="form-text text-muted">Residencial ou celular.</small>
                                </div>
                                <div class="form-group">
                                    <label for="senha">Senha</label>
                                    <input type="password" class="form-control" name="senha" id="senhaEdit" placeholder="Senha">
                                </div>


                                 <div class="form-group">
                                    <label for="confirmaSenha">Confirmar Senha</label>
                                    <input type="password" class="form-control" name="" id="confirmaSenha" placeholder="Confirmar senha">
                                </div> 


                                 <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                                </div> 

                                <button type="submit" class="btn btn-primary" value="save">Registrar</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                        </div>
                    </div>
                </div>


                 end Modal -->

            </div>
        </div>
    </section>
    <!-- banner part start-->

    <?php require("rodape.php"); ?>
