<?php require("cabecalho.php"); ?>

    <!-- modal login -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Login</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                

            <div class="modal-body">
                <form name="formLogin" method="post" action="<?= site_url('User_controller/auth') ?>">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha">
                    </div>
            </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" value="save">Logar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- fim do modal -->

<section class="banner_part">
    <div class="container" style="margin-top: 10%;">
        <h1> Cadastro </h1>
        <br>
        <br>
            <form id="novoUser" name="formNovoEvento" method="post" action="<?= site_url('User_controller/createUser') ?>" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="cpf">CPF</label>
                    <input type="text" class="form-control" name="cpf" id="cpf" placeholder="CPF" required>
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="nomeCompleto">Nome</label>
                    <input type="text" class="form-control" name="nome_user" id="nomeCompleto" placeholder="Nome Completo">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" id="emailCadastro" placeholder="Email">
                </div>
                <div class="form-group">
                    <label for="dataNascimento">Data de Nascimento</label>
                    <input type="text" class="form-control" name="dt_nasc" id="dataNascimento" placeholder="Data de Nascimento">
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="text" class="form-control" name="telefone" id="telefone" placeholder="Telefone">
                    <small class="form-text text-muted">Residencial ou celular.</small>
                </div>
                <div>
                    <label for="imagem_perfil">Foto de perfil</label><br>
                    <input type="file" name="arquivo">
                    <small class="form-text text muted">Foto de perfil não obrigatória.</small>
                </div>
                <br>
                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" class="form-control" name="senha" id="senhaCadastro" placeholder="Senha" required>
                </div>
                <div class="form-group">
                    <label for="confirmaSenha">Confirmar Senha</label>
                    <input type="password" class="form-control" name="confirmaSenha" id="confirmaSenha" placeholder="Confirmar senha" required>
                </div> 


                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1" required>
                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                </div>
            
            

                <button type="submit" id="submit" class="btn btn-primary" value="save">Registrar</button>
                
            </form>

            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
            <script>
                $(function(){
                    $("#novoUser").submit(function(){
                    var senha  = $("#senhaCadastro").val();
                    var senha2 = $("#confirmaSenha").val();
                        if(senha != senha2){
                            event.preventDefault();
                            alert("As senhas não são iguais!");
                        }
                    });
                });
            </script>

        </div>
    </div>
</section>
<br>
<br>

<?php require("rodape.php"); ?>