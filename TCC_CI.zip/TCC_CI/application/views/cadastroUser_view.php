<?php require("cabecalho.php"); ?>


aaaaaaaaaaaaaaaaaaaaaaaaaa eventoooos
<section class="banner_part">
    <div class="container" style="margin-top: 10%;">
        <h1> Cadastro </h1>
        <br>
        <br>
            <form name="formNovoEvento" method="post" action="<?= site_url('User_controller/createUser') ?> " >
                <div class="form-group">
                    <label for="cpf">CPF</label>
                    <input type="text" class="form-control" name="cpf" id="cpf" placeholder="CPF">
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="nomeCompleto">Nome</label>
                    <input type="text" class="form-control" name="nome_user" id="nomeCompleto" placeholder="Nome Completo">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                </div>
                <div class="form-group">
                    <label for="dataNascimento">Data de Nascimento</label>
                    <input type="text" class="form-control" name="dt_nasc" id="dataNascimento" placeholder="Data de Nascimento">
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="telefone">Telefone</label>
                    <input type="text" class="form-control" name="telefone" id="telefone" placeholder="Telefone">
                    <small class="form-text text-muted">Residencial ou celular.</small>
                </div>
                <div class="form-group">
                    <label for="senha">Senha</label>
                    <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha">
                </div>


                <!-- <div class="form-group">
                    <label for="confirmaSenha">Confirmar Senha</label>
                    <input type="password" class="form-control" name="" id="confirmaSenha" placeholder="Confirmar senha">
                </div> -->


                <!-- <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                </div> -->
            

                <button type="submit" class="btn btn-primary" value="save">Registrar</button>
            </form>
        </div>
    </div>
</section>
<br>
<br>

<?php require("rodape.php"); ?>