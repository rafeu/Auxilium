<?php require("cabecalho.php"); ?>

<section class="banner_part">
    <div class="container">
        <div class="row align-items-center" style="height: 500px;">
  
            <div id="tres_colunas" style="margin-top: 15%;">

                <div id="principal_sobre">
                    <h1 class="titulo_principal">SOBRE O AUXILIUM</h1>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repudiandae alias eligendi tempora dolores eveniet quisquam, quo fugit laboriosam. Quis repellat quibusdam at magnam facilis debitis neque doloribus eos modi magni.
                </div>

                <img id="abaixo_geral" src="<?= base_url();?>assets/imagens/abaixo_geral.png" alt="">

                <div style="clear: both;"> </div>

                <div id="tres_colu1">
                    <h1 class="titulo_colum">QUEM</h1>
                    <h1 class="sub_column">somos?</h1>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repudiandae alias eligendi tempora dolores eveniet quisquam, quo fugit laboriosam. Quis repellat quibusdam at magnam facilis debitis neque doloribus eos modi magni.
                        <div>
                            <img class="imgs_coluns" src="<?= base_url();?>assets/imagens/quem_img.png">
                        </div>
                </div>

                <div id="tres_colu2">
                    <h1 class="titulo_colum">O QUE</h1>
                    <h1 class="sub_column">fazemos?</h1>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repudiandae alias eligendi tempora dolores eveniet quisquam, quo fugit laboriosam. Quis repellat quibusdam at magnam facilis debitis neque doloribus eos modi magni.
                        <div>
                            <img class="imgs_coluns" src="<?= base_url();?>assets/imagens/fazemos_img.png">
                        </div>
                </div>

                <div id="tres_colu3">
                    <h1 class="titulo_colum">COMO</h1>
                    <h1 class="sub_column">participar?</h1>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Repudiandae alias eligendi tempora dolores eveniet quisquam, quo fugit laboriosam. Quis repellat quibusdam at magnam facilis debitis neque doloribus eos modi magni.
                        <div>
                            <img class="imgs_coluns" src="<?= base_url();?>assets/imagens/como_img.png">
                        </div>
                </div>

            </div> 

        </div>
    </div>
</section>
        <!-- modal login -->
                    
            <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalCenterTitle">Login</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                    <div class="modal-body">
                        <form name="formLogin" method="post" action="<?= site_url('User_controller/auth') ?> " >
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <label for="senha">Senha</label>
                                <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha">
                            </div>
                    </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary" value="save">Logar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
    
        <!-- fim do modal -->

</body>

<?php require("rodape.php"); ?>
