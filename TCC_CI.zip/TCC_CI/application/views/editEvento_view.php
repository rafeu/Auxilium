<?php require("cabecalho.php"); ?>

<section class="banner_part">
    <div class="container" style="margin-top: 10%;">
        <h1> Editar Evento </h1>
        <br>
        <br>
            <form name="formNovoEvento" method="post" action="<?= site_url('Eventos_controller/updateEvento')?>/<?= $row->id_evento; ?>" enctype="multipart/form-data" >
                <div class="form-group">
                    <label for="Nome">Nome do Evento</label>
                    <input type="text" class="form-control" name="nome_evento" id="nome_evento" value="<?= $row->nome_evento ?> ">
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" class="form-control" name="descricao" id="descricao" value="<?= $row->descricao ?> ">
                </div>
                <div class="form-group">
                    <label for="dataInicio">Data de inicio</label>
                    <input type="text" class="form-control" name="dataInicio" id="data" value="<?= $row->dataInicio ?> ">
                </div>
                <div class="form-group">
                    <label for="dataFim">Data de fim</label>
                    <input type="text" class="form-control" name="dataFim" id="data" value="<?= $row->dataFim ?> ">
                </div>
                <div class="form-group">
                    <label for="horaInicio">Horário de inicio</label>
                    <input type="text" class="form-control" name="horaInicio" id="hora" value="<?= $row->horaInicio ?> ">
                </div>
                <div class="form-group">
                    <label for="horaFim">Horário de fim</label>
                    <input type="text" class="form-control" name="horaFim" id="hora" value="<?= $row->horaFim?> ">
                </div>
                <div class="form-group">
                    <label for="iniciativa">Iniciativa</label>
                    <input type="text" class="form-control" name="iniciativa" id="iniciativa" value="<?= $row->iniciativa?> ">
                </div>


                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1" required>
                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                </div>
            

                <button type="submit" class="btn btn-primary" value="save">Atualizar</button>
            </form>
        </div>
    </div>
</section>
<br>
<br>

<?php require("rodape.php"); ?>