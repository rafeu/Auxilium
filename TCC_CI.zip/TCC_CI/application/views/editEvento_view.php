<?php require("cabecalho.php"); ?>

<section class="banner_part">
    <div class="container" style="margin-top: 10%;">
        <h1> Editar Evento </h1>
        <br>
        <br>
            <form name="formNovoEvento" method="post" action="<?= site_url('Eventos_controller/updateEvento')?>/<?= $row->id_evento; ?> " >
                <div class="form-group">
                    <label for="Nome">Nome do Evento</label>
                    <input type="text" class="form-control" name="nome" id="Nome" value="<?= $row->nome ?> "placeholder="Nome do evento">
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <input type="text" class="form-control" name="descricao" id="descricao" value="<?= $row->descricao ?> "placeholder="Descricao">
                </div>
                <div class="form-group">
                    <label for="dataInicio">Data de inicio</label>
                    <input type="text" class="form-control" name="dataInicio" id="data" value="<?= $row->dataInicio ?> "placeholder="Data de inicio">
                </div>
                <div class="form-group">
                    <label for="dataFim">Data de fim</label>
                    <input type="text" class="form-control" name="dataFim" id="data" value="<?= $row->dataFim ?> "placeholder="Data de Fim">
                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                </div>
                <div class="form-group">
                    <label for="horaInicio">Horário de inicio</label>
                    <input type="text" class="form-control" name="horaInicio" id="hora" value="<?= $row->horaInicio ?> "placeholder="Horário de inicio">
                    <small class="form-text text-muted">Residencial ou celular.</small>
                </div>
                <div class="form-group">
                    <label for="horaFim">Horário de fim</label>
                    <input type="text" class="form-control" name="horaFim" id="hora" value="<?= $row->horaFim?> "placeholder="Horário de fim">
                </div>


                <!-- <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                </div> -->
            

                <button type="submit" class="btn btn-primary" value="save">Atualizar</button>
            </form>
        </div>
    </div>
</section>
<br>
<br>

<?php require("rodape.php"); ?>