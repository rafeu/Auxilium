<?php require("cabecalho.php"); ?>

    <section class="special_cource padding_top" style="margin-top: 5%; margin-bottom: 13%;">
        <div class="container">


                
            <div class="row justify-content-center" style="margin-bottom: 5%;">
                <div class="col-xl-5">
                    <div class="section_tittle text-center">
                        <h3>Esqueceu sua senha?</h3>
                    </div>

                    <h5> Informe seu e-mail e enviaremos instruções para você criar sua senha. </h5>
                    <br><br>
                <form action="#">
                    <div class="form-group">
                        <label for="esqueceuSenha">Digite seu email.</label>
                        <input type="email" class="form-control" name="esqueceuSenha" id="esqueceuSenha">
                    </div>
                    <input type="submit" class="btn btn-primary" style="width:100%;">
                </form>
                
                </div>
            </div>
        </div>
    </section>

 

<?php require("rodape.php"); ?>