<?php require("cabecalho.php"); ?>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

  <div class="container">
    <div class="row">
    
          <div class="jumbotron  border_radius_none" style="list-style: none; border-right: solid 2px black; width: 25%; float: left; height: 550px">
            <div style="width: 215%;">
              <img class="navbar-brand" style="margin-bottom: 5%; margin-top: -5%; margin-left: 1.5%;" src="<?= base_url();?>assets/imagens/usuario.png"></a>
            </div>

            <!--ACCESS MENUS FOR usuario comum  -->
            <?php if($this->session->userdata('tip_user')==='0'):?>
              <li class="link" style="font-size: 30px; border-bottom: solid 2px black; text-align: center; margin-bottom: 10%;" href="#"><?= $nome[0]; ?></li>
              <li class="active" style="margin-bottom: 3%;"><a class="link" href="#">Meus Eventos</a></li>
              <li style="margin-bottom: 3%;"><a class="link" href="#">Minhas Doações</a></li>
              <li style="margin-bottom: 3%;"><a class="link" href="#">Configurações</a></li>
              <li style="margin-bottom: -5%;"><a class="link" href="<?php echo site_url('User_controller/logout');?>">Deslogar</a></li>

            <!--ACCESS MENUS FOR admin -->
            <?php elseif($this->session->userdata('tip_user')==='1'):?>
              <li class="link" style="font-size: 30px; border-bottom: solid 2px black; text-align: center; margin-bottom: 10%;" href="#"><?= $nome[0]; ?></li>
              <li class="active" style="margin-bottom: 3%;"><a class="link" href="#">Meus Eventos</a></li>
              <li style="margin-bottom: 3%;"><a class="link" href="<?= site_url('Doacao_controller/userDoacao');?>/<?= $this->session->userdata("cpf"); ?>">Minhas Doações</a></li>
              <li style="margin-bottom: 3%;"><a class="link" href="#">Configurações</a></li>
              <li style="margin-bottom: -5%;"><a class="link" href="<?php echo site_url('User_controller/logout');?>">Deslogar</a></li>

            <?php endif;?>
              
          </div>
          <div class="jumbotron border_radius_none" style="float: left; width: 75%; height: 550px">
            <h2>Editar Doação</h2>
            <br><br>

            <form name="formNovoEvento" method="post" action="<?= site_url('Doacao_controller/updateDoacao')?>/<?= $row->cpf; ?> " >

                  <div class="form-group">
                      <label for="tipo_doacao">Tipo de doação</label>
                      <input type="text" class="form-control" name="tipo_doacao" id="tipo_doacao" value="<?= $row->tipo_doacao; ?>" required>
                  </div>
                  <div class="form-group">
                      <label for="qtd_doacao">Quantidade</label>
                      <input type="text" class="form-control" name="qtd_doacao" id="qtd_doacao" value="<?= $row->qtd_doacao; ?>" required>
                  </div>
                  <div class="form-group">
                      <label for="descricao_doacao">descricao_doacao</label>
                      <input type="text" class="form-control" name="descricao_doacao" id="descricao_doacao" value="<?= $row->descricao_doacao; ?>" required>
                  </div>
              <button type="submit" class="btn btn-primary" value="save">Atualizar</button>
            </form>
            
          </div>

    </div>
  </div>

<?php require("rodape.php"); ?>
