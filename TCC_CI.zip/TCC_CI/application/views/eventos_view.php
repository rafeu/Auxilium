<?php require("cabecalho.php"); ?>

    <!-- modal login -->
    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Login</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                

            <div class="modal-body">
                <form name="formLogin" method="post" action="<?= site_url('User_controller/auth') ?> " >
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" class="form-control" name="senha" id="senha" placeholder="Senha">
                    </div>
            </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary" value="save">Logar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- fim do modal -->

    <!-- Modal Cadastro -->
    <div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Cadastro</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form name="formNovoEvento" method="post" action="<?= site_url('Eventos_controller/createEvento') ?> " >
                    <div class="form-group">
                        <label for="Nome">Nome do Evento</label>
                        <input type="text" class="form-control" name="nome" id="Nome" placeholder="Nome do evento">
                        <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                    </div>
                    <div class="form-group">
                        <label for="descricao">Descrição</label>
                        <input type="text" class="form-control" name="descricao" id="descricao" placeholder="Descricao">
                    </div>
                    <div class="form-group">
                        <label for="dataInicio">Data de inicio</label>
                        <input type="text" class="form-control" name="dataInicio" id="data" placeholder="Data de inicio">
                    </div>
                    <div class="form-group">
                        <label for="dataFim">Data de fim</label>
                        <input type="text" class="form-control" name="dataFim" id="data" placeholder="Data de Fim">
                        <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                    </div>
                    <div class="form-group">
                        <label for="horaInicio">Horário de inicio</label>
                        <input type="text" class="form-control" name="horaInicio" id="hora" placeholder="Horário de inicio">
                        <small class="form-text text-muted">Residencial ou celular.</small>
                    </div>
                    <div class="form-group">
                        <label for="horaFim">Horário de fim</label>
                        <input type="text" class="form-control" name="horaFim" id="hora" placeholder="Horário de fim">
                    </div>

                    <!-- <div class="form-group form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                    </div> -->

                    <button type="submit" class="btn btn-primary" value="save">Cadastrar</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
            </div>
            </div>
        </div>
    </div>
    <!-- end Modal -->

    <!--::review_part start::-->
    <section class="special_cource padding_top" style="margin-top: 5%; margin-bottom: 13%;">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-5">
                    <div class="section_tittle text-center">
                        <h2>Eventos</h2>
                    </div>
                </div>
            </div>
            <div class="row">

                <?php foreach($result as $evento){ ?>

                <div class="col-sm-6 col-lg-4">
                    <div class="single_special_cource">
                        <img src="<?= base_url(); ?>assets/imagens/evento.jpg" class="special_img" alt="">
                        <div class="special_cource_text">
                            <a href="course-details.html" class="btn_4"><?= $evento->nome_evento; ?></a>
                            <h4><?= $evento->dataInicio?> - <?=$evento->horaInicio ?></h4>
                            <a href="course-details.html">
                                <h3><?= $evento->nome_evento; ?></h3>
                            </a>
                            <p class="card-text"><?= $evento->descricao; ?></p>
                            <div class="author_info">
                                <div class="author_img">
                                    <img src="img/author/author_1.png" alt="">
                                    <div class="author_info_text">
                                        <p>Conduct by:</p>
                                        <h5><a href="#">James Well</a></h5>
                                    </div>
                                </div>
                                <div class="author_rating">
                                    <div class="rating">
                                        <a href="#"><img src="img/icon/color_star.svg" alt=""></a>
                                        <a href="#"><img src="img/icon/color_star.svg" alt=""></a>
                                        <a href="#"><img src="img/icon/color_star.svg" alt=""></a>
                                        <a href="#"><img src="img/icon/color_star.svg" alt=""></a>
                                        <a href="#"><img src="img/icon/star.svg" alt=""></a>
                                    </div>
                                    <p>3.8 Ratings</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php } ?>

            </div>
        </div>
    </section>
    <!--::blog_part end::-->

<?php require("rodape.php"); ?>