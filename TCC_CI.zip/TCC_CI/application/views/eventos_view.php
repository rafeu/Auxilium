<?php require("cabecalho.php"); ?>

    <!-- banner part start-->
    <section class="banner_part">
        <div class="container">
            <div class="row align-items-center" style="height: 500px;">

            <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalCadastro">
                Cadastrar
                </button>

                <!-- Modal Cadastro -->
                <div class="modal fade" id="modalCadastro" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalCenterTitle">Cadastro</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form name="formNovoEvento" method="post" action="<?= site_url('Eventos_controller/createEvento') ?> " >
                                <div class="form-group">
                                    <label for="Nome">Nome do Evento</label>
                                    <input type="text" class="form-control" name="nome" id="Nome" placeholder="Nome do evento">
                                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                                </div>
                                <div class="form-group">
                                    <label for="descricao">Descrição</label>
                                    <input type="text" class="form-control" name="descricao" id="descricao" placeholder="Descricao">
                                </div>
                                <div class="form-group">
                                    <label for="dataInicio">Data de inicio</label>
                                    <input type="text" class="form-control" name="dataInicio" id="data" placeholder="Data de inicio">
                                </div>
                                <div class="form-group">
                                    <label for="dataFim">Data de fim</label>
                                    <input type="text" class="form-control" name="dataFim" id="data" placeholder="Data de Fim">
                                    <small class="form-text text-muted">O campo preenche a pontuação sozinho.</small>
                                </div>
                                <div class="form-group">
                                    <label for="horaInicio">Horário de inicio</label>
                                    <input type="text" class="form-control" name="horaInicio" id="hora" placeholder="Horário de inicio">
                                    <small class="form-text text-muted">Residencial ou celular.</small>
                                </div>
                                <div class="form-group">
                                    <label for="horaFim">Horário de fim</label>
                                    <input type="text" class="form-control" name="horaFim" id="hora" placeholder="Horário de fim">
                                </div>

                                <!-- <div class="form-group form-check">
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1">
                                    <label class="form-check-label" for="exampleCheck1">Não sou um robô.</label>
                                </div> -->

                                <button type="submit" class="btn btn-primary" value="save">Cadastrar</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
                        </div>
                        </div>
                    </div>
                </div>
                <!-- end Modal -->

                <div class="row" style="margin-top: 35%;">
                <!-- <div class="row"> -->

                    <?php foreach($result as $evento){ ?>

                        <div class="col-lg-6 col-md-3 col-mb-4" style="max-width: 33.33%">
                        <div class="card" style="width: 18rem; margin-top: 40%;">
                            <!-- <img class="card-img-top" src="<?= base_url(); ?>assets/imagens/evento.jpg" alt="Imagem de capa do card"> -->
                            <div class="card-text" style="background-image: url(<?= base_url(); ?>assets/imagens/evento.jpg); height: 75px;" class="card-img-top" alt="..."></div>
                            <div class="card-body" style="max-height: 163px; overflow: hidden; text-overflow: ellipsis">
                                <a href="<?= site_url('Eventos_controller/perfilEvento');?>/<?= $evento->id_evento ?>"><h5 class="card-title"><?= $evento->nome; ?></h5></a>
                                <div class="card-text" style="-webkit-line-clamp: 3; overflow: hidden; display: -webkit-box; -webkit-box-orient: vertical;" ><?= $evento->descricao; ?></div>
                            </div>
                            <div class="card-footer">
                                <a href="#" class="btn btn-primary" style="padding: 5px; display: inline;" >Acessar</a>
                                <div style="float: right;">
                                    <a href="<?= site_url('Eventos_controller/indexEditar');?>/<?=$evento->id_evento; ?>">Editar</a> | 
                                    <a href="<?= site_url('Eventos_controller/excluirEvento');?>/<?=$evento->id_evento; ?>">Excluir</a>
                                </div>
                            </div>
                        </div>
                        </div>
                    

                    <?php } ?>

                </div>               

            </div>
        </div>
    </section>
    <!-- banner part start-->

    <?php require("rodape.php"); ?>
